# platform = Mozilla Firefox
. /usr/share/scap-security-guide/remediation_functions

firefox_js_setting "stig_settings.js" "general.config.filename" "\"stig.cfg\""
