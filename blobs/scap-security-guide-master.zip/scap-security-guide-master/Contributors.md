<!---
This file is generated using the generate-contributors.py script. DO NOT MANUALLY EDIT!!!!
Last Modified: 2016-11-23 08:32
--->

The following people have contributed to the SCAP Security Guide project
(listed in alphabetical order):

* Gabe Alford <redhatrises@gmail.com>
* Christopher Anderson <cba@fedoraproject.org>
* Chuck Atkins <chuck.atkins@kitware.com>
* Molly Jo Bault <Molly.Jo.Bault@ballardtech.com>
* Joseph Bisch <joseph.bisch@gmail.com>
* Jeffrey Blank <blank@eclipse.ncsc.mil>
* Blake Burkhart <blake.burkhart@us.af.mil>
* Patrick Callahan <pmc@patrickcallahan.com>
* Nick Carboni <ncarboni@redhat.com>
* Frank Caviggia <fcaviggi@ra.iad.redhat.com>
* Eric Christensen <echriste@redhat.com>
* Caleb Cooper <coopercd@ornl.gov>
* Maura Dailey <maura@eclipse.ncsc.mil>
* Klaas Demter <demter@atix.de>
* Jean-Baptiste Donnette <jean-baptiste.donnette@epita.fr>
* drax <applezip@gmail.com>
* Greg Elin <gregelin@gitmachines.com>
* Andrew Gilmore <agilmore2@gmail.com>
* Joshua Glemza <jglemza@nasa.gov>
* Steve Grubb <sgrubb@redhat.com>
* Trey Henefield <thenefield@gmail.com>
* Robin Price II <robin@redhat.com>
* Jeremiah Jahn <jeremiah@goodinassociates.com>
* Stephan Joerrens <Stephan.Joerrens@fiduciagad.de>
* Yuli Khodorkovskiy <ykhodorkovskiy@tresys.com>
* Luke Kordell <luke.t.kordell@lmco.com>
* kspargur <kspargur@kspargur.csb>
* Fen Labalme <fen@civicactions.com>
* Jan Lieskovsky <jlieskov@redhat.com>
* Šimon Lukašík <slukasik@redhat.com>
* Jamie Lorwey Martin <jlmartin@redhat.com>
* Michael McConachie <michael@redhat.com>
* Rodney Mercer <rmercer@harris.com>
* Brian Millett <bmillett@gmail.com>
* mmosel <mmosel@kde.example.com>
* Zbynek Moravec <zmoravec@redhat.com>
* Kazuo Moriwaka <moriwaka@users.noreply.github.com>
* Michael Moseley <michael@eclipse.ncsc.mil>
* Joe Nall <joe@nall.com>
* Michele Newman <mnewman@redhat.com>
* Kaustubh Padegaonkar <theTuxRacer@gmail.com>
* Michael Palmiotto <mpalmiotto@tresys.com>
* pcactr <paul.c.arnold4.ctr@mail.mil>
* Kenneth Peeples <kennethwpeeples@gmail.com>
* Frank Lin PIAT <fpiat@klabs.be>
* Martin Preisler <mpreisle@redhat.com>
* T.O. Radzy Radzykewycz <radzy@windriver.com>
* Rick Renshaw <Richard_Renshaw@xtoenergy.com>
* Chris Reynolds <c.reynolds82@gmail.com>
* Pat Riehecky <riehecky@fnal.gov>
* Joshua Roys <roysjosh@gmail.com>
* rrenshaw <bofh69@yahoo.com>
* Ray Shaw (Cont ARL/CISD) rvshaw <rvshaw@esme.arl.army.mil>
* Willy Santos <wsantos@redhat.com>
* Gautam Satish <gautams@hpe.com>
* Watson Sato <wsato@redhat.com>
* Satoru SATOH <satoru.satoh@gmail.com>
* Spencer Shimko <sshimko@tresys.com>
* Francisco Slavin <fslavin@tresys.com>
* David Smith <dsmith@eclipse.ncsc.mil>
* Kevin Spargur <kspargur@redhat.com>
* Kenneth Stailey <kstailey.lists@gmail.com>
* Leland Steinke <leland.j.steinke.ctr@mail.mil>
* Philippe Thierry <phil@reseau-libre.net>
* Paul Tittle <ptittle@cmf.nrl.navy.mil>
* Jeb Trayer <jeb.d.trayer@uscg.mil>
* Shawn Wells <shawn@redhat.com>
* Rob Wilmoth <rwilmoth@redhat.com>
* Lucas Yamanishi <lucas.yamanishi@onyxpoint.com>
* Kevin Zimmerman <kevin.zimmerman@kitware.com>
* Jan Černý <jcerny@redhat.com>
* Michal Šrubař <msrubar@redhat.com>
