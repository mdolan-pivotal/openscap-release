# platform = Red Hat Enterprise Linux 7
chmod 640 /etc/openstack-dashboard/local_settings
