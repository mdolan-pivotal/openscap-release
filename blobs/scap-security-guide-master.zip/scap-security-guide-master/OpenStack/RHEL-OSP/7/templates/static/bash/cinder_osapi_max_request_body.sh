# platform = Red Hat Enterprise Linux 7
openstack-config --set /etc/cinder/cinder.conf DEFAULT osapi_max_request_body_size 114688
