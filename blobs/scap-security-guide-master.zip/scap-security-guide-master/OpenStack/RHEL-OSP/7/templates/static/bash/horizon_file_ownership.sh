# platform = Red Hat Enterprise Linux 7
chown root /etc/openstack-dashboard/local_settings
chgrp horizon /etc/openstack-dashboard/local_settings
