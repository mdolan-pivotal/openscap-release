# platform = Red Hat Enterprise Linux 7
chmod 640 /etc/cinder/cinder.conf
chmod 640 /etc/cinder/api-paste.ini
chmod 640 /etc/cinder/policy.json
chmod 640 /etc/cinder/rootwrap.conf
