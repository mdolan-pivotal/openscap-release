# platform = Red Hat Enterprise Linux 7
openstack-config --set /etc/cinder/cinder.conf DEFAULT auth_strategy keystone
