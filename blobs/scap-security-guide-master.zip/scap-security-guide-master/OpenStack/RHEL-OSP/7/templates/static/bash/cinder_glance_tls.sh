# platform = Red Hat Enterprise Linux 7
openstack-config --set /etc/cinder/cinder.conf DEFAULT glance_api_insecure False
