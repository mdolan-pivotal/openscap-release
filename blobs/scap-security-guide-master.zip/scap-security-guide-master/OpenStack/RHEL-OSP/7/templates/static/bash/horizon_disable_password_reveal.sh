# platform = Red Hat Enterprise Linux 7
openstack-config --set /etc/openstack-dashboard/local_settings DEFAULT DISABLE_PASSWORD_REVEAL True
