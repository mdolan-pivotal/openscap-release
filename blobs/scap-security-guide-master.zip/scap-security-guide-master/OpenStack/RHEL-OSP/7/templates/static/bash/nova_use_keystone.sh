# platform = Red Hat Enterprise Linux 7
openstack-config --set /etc/nova/nova.conf DEFAULT auth_strategy keystone
