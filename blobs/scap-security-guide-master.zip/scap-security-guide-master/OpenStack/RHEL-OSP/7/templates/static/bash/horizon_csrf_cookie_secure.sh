# platform = Red Hat Enterprise Linux 7
openstack-config --set /etc/openstack-dashboard/local_settings DEFAULT CSRF_COOKIE_SECURE True
