# platform = Red Hat Enterprise Linux 7
openstack-config --set /etc/neutron/neutron.conf DEFAULT auth_strategy keystone
