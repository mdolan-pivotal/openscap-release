# platform = Red Hat Enterprise Linux 7
chmod 640 /etc/neutron/neutron.conf
chmod 640 /etc/neutron/api-paste.ini
chmod 640 /etc/neutron/policy.json
chmod 640 /etc/neutron/rootwrap.conf
