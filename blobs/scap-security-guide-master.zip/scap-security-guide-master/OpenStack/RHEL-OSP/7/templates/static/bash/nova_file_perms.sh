# platform = Red Hat Enterprise Linux 7
chmod 640 /etc/nova/nova.conf
chmod 640 /etc/nova/api-paste.ini
chmod 640 /etc/nova/policy.json
chmod 640 /etc/nova/rootwrap.conf
