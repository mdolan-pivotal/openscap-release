# platform = multi_platform_all
sed -i '/^vc\//d' /etc/securetty
