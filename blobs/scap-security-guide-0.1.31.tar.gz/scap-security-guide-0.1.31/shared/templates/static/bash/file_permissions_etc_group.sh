# platform = multi_platform_rhel
chmod 644 /etc/group
