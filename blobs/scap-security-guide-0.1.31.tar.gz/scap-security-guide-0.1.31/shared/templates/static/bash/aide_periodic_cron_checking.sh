# platform = multi_platform_rhel
echo "05 4 * * * root /usr/sbin/aide --check" >> /etc/crontab
