# platform = multi_platform_rhel, multi_platform_sle
chmod 0644 /etc/passwd
