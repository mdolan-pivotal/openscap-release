# platform = Red Hat Enterprise Linux 6
/sbin/grubby --update-kernel=ALL --args="audit=1"
