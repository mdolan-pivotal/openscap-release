# platform = multi_platform_all
sed -i '/ttyS/d' /etc/securetty
