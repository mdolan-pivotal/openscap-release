# platform = multi_platform_rhel, Red Hat Enterprise Linux 5, multi_platform_sle
chgrp root /etc/passwd
