# platform = multi_platform_all
echo > /etc/securetty
