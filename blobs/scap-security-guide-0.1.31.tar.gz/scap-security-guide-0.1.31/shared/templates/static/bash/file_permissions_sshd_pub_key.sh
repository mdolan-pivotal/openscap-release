# platform = multi_platform_rhel

chmod 0644 /etc/ssh/*.pub
