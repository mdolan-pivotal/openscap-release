# platform = multi_platform_rhel
chmod 0000 /etc/gshadow
