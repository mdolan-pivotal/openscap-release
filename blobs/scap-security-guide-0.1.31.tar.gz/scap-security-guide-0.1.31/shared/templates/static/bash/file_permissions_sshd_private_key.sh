# platform = multi_platform_rhel

chmod 0640 /etc/ssh/*_key
