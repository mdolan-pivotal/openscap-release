# platform = multi_platform_rhel, Red Hat Enterprise Linux 5
chown root /etc/gshadow
