# platform = Red Hat Enterprise Linux 7, multi_platform_fedora
ln -sf /dev/null /etc/systemd/system/ctrl-alt-del.target
