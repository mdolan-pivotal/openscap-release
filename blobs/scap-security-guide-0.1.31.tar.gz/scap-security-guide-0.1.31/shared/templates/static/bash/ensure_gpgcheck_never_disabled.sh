# platform = multi_platform_rhel
sed -i 's/gpgcheck=.*/gpgcheck=1/g' /etc/yum.repos.d/*
