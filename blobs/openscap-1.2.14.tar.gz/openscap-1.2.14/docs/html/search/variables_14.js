var searchData=
[
  ['xccdf_5ffile',['xccdf_file',['../structxccdf__session.html#aa2b3c6ac18ef983d8cd89090ac59474f',1,'xccdf_session']]],
  ['xsi_5fnil',['xsi_nil',['../structoval__entity.html#aa0fd64befc66d939b0336938210ccbb3',1,'oval_entity']]]
];
