var searchData=
[
  ['validate',['validate',['../structxccdf__session.html#a6e3ac1576b0f5afe7b7f0f384d55bdc1',1,'xccdf_session']]],
  ['value',['value',['../structxccdf__value__binding.html#a252ab254dd70ce7ad5de4c50518cfc50',1,'xccdf_value_binding']]],
  ['values',['values',['../structxccdf__policy.html#a6439c166d042a4a66361bdaf066de2bb',1,'xccdf_policy']]],
  ['vardef_5fmap',['vardef_map',['../structoval__definition__model.html#adcd2650921095a303578e531fd73273c',1,'oval_definition_model']]],
  ['variable_5fbindings',['variable_bindings',['../structoval__syschar.html#af8cfd1e99c042a559a5f2f267270787b',1,'oval_syschar']]],
  ['variable_5finstance',['variable_instance',['../structoval__syschar.html#ababf3e4fb2925d0cbc18f99573db5ef2',1,'oval_syschar']]],
  ['variable_5finstance_5fhint',['variable_instance_hint',['../structoval__syschar.html#a7ac7021f5688c7089449c4a6082c651f',1,'oval_syschar::variable_instance_hint()'],['../structoval__result__definition.html#a5d52b2e9bd488405b8ff1be6451661d2',1,'oval_result_definition::variable_instance_hint()']]],
  ['version',['version',['../structoscap__source.html#ad4e584075855f5ab3774d1b0f53878c6',1,'oscap_source::version()'],['../structxccdf__version__info.html#a9b56b90188f903fa4bab03b394b449e7',1,'xccdf_version_info::version()']]],
  ['vflags',['vflags',['../structrpmverify__res.html#af104e0a41ea96a5a547c6dd98f00da3f',1,'rpmverify_res::vflags()'],['../structrpmverify__res.html#ade2dba60f0c914e573c66fb8189a7f3b',1,'rpmverify_res::vflags()']]]
];
