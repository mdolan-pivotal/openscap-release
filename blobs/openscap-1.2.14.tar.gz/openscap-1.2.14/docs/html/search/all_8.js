var searchData=
[
  ['href',['href',['../structoval__content__resource.html#aac5c2186f95dba38b732d20e6942f7e0',1,'oval_content_resource']]],
  ['html',['html',['../structoscap__text__traits.html#ae9fb73ffedfd786dc6f0488037416769',1,'oscap_text_traits']]]
];
