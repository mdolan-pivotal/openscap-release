var searchData=
[
  ['ldap57_2ec',['ldap57.c',['../ldap57_8c.html',1,'']]]
];
