var searchData=
[
  ['cpe_5fformat_5ft',['cpe_format_t',['../group__cpeuri.html#gaae53e0c2b5bf2944830957a0cbcee53f',1,'cpe_name.h']]],
  ['cpe_5flang_5foper_5ft',['cpe_lang_oper_t',['../group__cpelang.html#gacbb2c8c91d3bb516182bb64c6d8f7d82',1,'cpe_lang.h']]],
  ['cpe_5fpart_5ft',['cpe_part_t',['../group__cpeuri.html#ga683b693cae1d4b68f257be24c4cc2ab7',1,'cpe_name.h']]],
  ['cvss_5faccess_5fcomplexity',['cvss_access_complexity',['../group__CVSS.html#gac72669f8923c6fbe496c6e8403d620bf',1,'cvss_score.h']]],
  ['cvss_5faccess_5fvector',['cvss_access_vector',['../group__CVSS.html#ga9ad0902191f4c15a8b550fceb439b1f6',1,'cvss_score.h']]],
  ['cvss_5fauthentication',['cvss_authentication',['../group__CVSS.html#gada91b873060b93859ef8bccbeeb39098',1,'cvss_score.h']]],
  ['cvss_5fcategory',['cvss_category',['../group__CVSS.html#gafebb951da0f6dafea63d34d9eafd3ba0',1,'cvss_score.h']]],
  ['cvss_5fcia_5fimpact',['cvss_cia_impact',['../group__CVSS.html#ga974cf6cd38cee13b18f0eda1bfe56271',1,'cvss_score.h']]],
  ['cvss_5fcia_5frequirement',['cvss_cia_requirement',['../group__CVSS.html#ga4360c9178aa1ed950688fdb29262b6b7',1,'cvss_score.h']]],
  ['cvss_5fcollateral_5fdamage_5fpotential',['cvss_collateral_damage_potential',['../group__CVSS.html#ga844231d7a149bce3f291e16f2901bcf2',1,'cvss_score.h']]],
  ['cvss_5fexploitability',['cvss_exploitability',['../group__CVSS.html#ga28acecb4abe0094330fd37754e1e659b',1,'cvss_score.h']]],
  ['cvss_5fremediation_5flevel',['cvss_remediation_level',['../group__CVSS.html#ga2bdfd0521fe93b4ae144a5da6a178fc8',1,'cvss_score.h']]],
  ['cvss_5freport_5fconfidence',['cvss_report_confidence',['../group__CVSS.html#ga756fc94e4b4d0100afb4f4f389e15430',1,'cvss_score.h']]],
  ['cvss_5ftarget_5fdistribution',['cvss_target_distribution',['../group__CVSS.html#gacf6165b4a87321f2a7acd52aca91c57b',1,'cvss_score.h']]]
];
