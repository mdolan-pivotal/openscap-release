var searchData=
[
  ['err_5fqueue',['err_queue',['../structerr__queue.html',1,'']]]
];
